'use client';

import { useActionState, useState } from 'react';
import { keepValues } from '@/components/keepValues';
import Link from 'next/link';
import { adminCreateListing, adminUpdateListing } from '@/lib/admin-actions';
import type { FormState } from '@/lib/actions';
import type { ImageCredit, ListingView } from '@/lib/types';
import { BODY_STYLES, isPlaceholder } from '@/lib/types';
import type { Photo } from '@/lib/photos';
import PhotoFinder from './PhotoFinder';
import PhotoUploader from '@/components/PhotoUploader';
import type { UploadMode } from '@/lib/storage';
import FormMessage, { FieldError } from '@/components/FormMessage';

const INITIAL: FormState = { ok: false, message: '' };
const CONDITIONS = ['Used', 'Certified', 'Restored', 'New', 'Project'];
const FUELS = ['Gasoline', 'Diesel', 'Hybrid', 'Electric'];
const DRIVETRAINS = ['RWD', 'FWD', 'AWD', '4WD'];
const TRANSMISSIONS = ['Automatic', 'Manual'];

export default function AdminListingForm({
  listing,
  defaultPhotoQuery = '',
  uploadMode,
}: {
  listing?: ListingView;
  defaultPhotoQuery?: string;
  uploadMode: UploadMode;
}) {
  const editing = Boolean(listing);
  const [state, action, pending] = useActionState(
    editing ? adminUpdateListing : adminCreateListing,
    INITIAL,
  );

  // Photos the editor has chosen to keep; removing one just drops it from this list.
  const [images, setImages] = useState<string[]>(listing?.images ?? []);
  const [credits, setCredits] = useState<Record<string, ImageCredit>>(() =>
    Object.fromEntries((listing?.image_credits ?? []).map((c) => [c.src, c])),
  );

  /** Adding a real photo retires the drawn placeholders. */
  const addPhotos = (photos: Photo[]) => {
    setImages((prev) => {
      const next = prev.filter((src) => !isPlaceholder(src));
      for (const p of photos) if (!next.includes(p.src)) next.push(p.src);
      return next;
    });
    setCredits((prev) => {
      const next = { ...prev };
      for (const p of photos) {
        next[p.src] = { src: p.src, author: p.author, license: p.license, licenseUrl: p.licenseUrl, sourceUrl: p.sourceUrl };
      }
      return next;
    });
  };

  const creditList = images.map((src) => credits[src]).filter(Boolean);

  const err = (k: string) => state.errors?.[k];

  return (
    <form onSubmit={keepValues(action)} className="space-y-6">
      <FormMessage state={state} />
      {editing && <input type="hidden" name="id" value={listing!.id} />}

      <fieldset className="card p-5">
        <legend className="px-2 text-sm font-semibold uppercase tracking-wide text-brand-300">Vehicle</legend>
        <div className="mt-3 space-y-4">
          <div>
            <label className="label" htmlFor="title">Listing title</label>
            <input id="title" name="title" className="field" required defaultValue={listing?.title} />
            <FieldError message={err('title')} />
          </div>

          <div className="grid gap-4 sm:grid-cols-3">
            <div>
              <label className="label" htmlFor="body_style">Vehicle type</label>
              <select id="body_style" name="body_style" className="field" required defaultValue={listing?.body_style ?? ''}>
                <option value="" disabled>Choose…</option>
                {BODY_STYLES.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
              <FieldError message={err('body_style')} />
            </div>
            <div>
              <label className="label" htmlFor="make">Make</label>
              <input id="make" name="make" className="field" required defaultValue={listing?.make} />
              <FieldError message={err('make')} />
            </div>
            <div>
              <label className="label" htmlFor="model">Model</label>
              <input id="model" name="model" className="field" required defaultValue={listing?.model} />
              <FieldError message={err('model')} />
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-4">
            <div>
              <label className="label" htmlFor="year">Year</label>
              <input id="year" name="year" type="number" className="field" required defaultValue={listing?.year} />
              <FieldError message={err('year')} />
            </div>
            <div>
              <label className="label" htmlFor="price">Price (USD)</label>
              <input id="price" name="price" type="number" className="field" required defaultValue={listing?.price} />
              <FieldError message={err('price')} />
            </div>
            <div>
              <label className="label" htmlFor="mileage">Mileage</label>
              <input id="mileage" name="mileage" type="number" className="field" required defaultValue={listing?.mileage} />
              <FieldError message={err('mileage')} />
            </div>
            <div>
              <label className="label" htmlFor="passengers">Passengers</label>
              <input id="passengers" name="passengers" type="number" className="field" required defaultValue={listing?.passengers} />
              <FieldError message={err('passengers')} />
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-4">
            <div>
              <label className="label" htmlFor="condition">Condition</label>
              <select id="condition" name="condition" className="field" defaultValue={listing?.condition ?? 'Used'}>
                {CONDITIONS.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="label" htmlFor="fuel">Fuel</label>
              <select id="fuel" name="fuel" className="field" defaultValue={listing?.fuel ?? 'Gasoline'}>
                {FUELS.map((f) => <option key={f} value={f}>{f}</option>)}
              </select>
            </div>
            <div>
              <label className="label" htmlFor="transmission">Transmission</label>
              <select id="transmission" name="transmission" className="field" defaultValue={listing?.transmission ?? 'Automatic'}>
                {TRANSMISSIONS.map((t) => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="label" htmlFor="drivetrain">Drivetrain</label>
              <select id="drivetrain" name="drivetrain" className="field" defaultValue={listing?.drivetrain ?? 'RWD'}>
                {DRIVETRAINS.map((d) => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-4">
            <div>
              <label className="label" htmlFor="exterior_color">Exterior</label>
              <input id="exterior_color" name="exterior_color" className="field" defaultValue={listing?.exterior_color ?? 'Black'} />
            </div>
            <div>
              <label className="label" htmlFor="interior_color">Interior</label>
              <input id="interior_color" name="interior_color" className="field" defaultValue={listing?.interior_color ?? 'Black'} />
            </div>
            <div>
              <label className="label" htmlFor="city">City</label>
              <input id="city" name="city" className="field" required defaultValue={listing?.city} />
              <FieldError message={err('city')} />
            </div>
            <div>
              <label className="label" htmlFor="state">State</label>
              <input id="state" name="state" className="field" required maxLength={2} defaultValue={listing?.state} />
              <FieldError message={err('state')} />
            </div>
          </div>

          <div>
            <label className="label" htmlFor="vin">VIN (optional)</label>
            <input id="vin" name="vin" className="field" defaultValue={listing?.vin ?? ''} />
          </div>
        </div>
      </fieldset>

      <fieldset className="card p-5">
        <legend className="px-2 text-sm font-semibold uppercase tracking-wide text-brand-300">Photos</legend>

        <div className="mt-3">
          <PhotoUploader
            images={images}
            onChange={setImages}
            mode={uploadMode}
            captions={Object.fromEntries(Object.values(credits).map((c) => [c.src, `${c.author} · ${c.license}`]))}
          />
        </div>

        <input type="hidden" name="image_credits" value={JSON.stringify(creditList)} />

        {images.length > 0 && images.every(isPlaceholder) && (
          <p className="mt-3 text-xs text-slate-400">
            This listing only has drawn placeholders, so the public site fills in matching photos
            automatically. Add photos here to choose exactly which ones appear.
          </p>
        )}

        <div className="mt-4">
          <PhotoFinder defaultQuery={defaultPhotoQuery} selected={images} onAdd={addPhotos} />
        </div>

        <div className="mt-4">
          <label className="label" htmlFor="image_urls">Add photos by URL — one per line</label>
          <textarea
            id="image_urls" name="image_urls" rows={3} className="field"
            placeholder={'https://example.com/photo-1.jpg\nhttps://example.com/photo-2.jpg'}
          />
          <p className="mt-1.5 text-xs text-slate-500">
            Rendered straight from the source, so nothing is stored on our side.
          </p>
        </div>

      </fieldset>

      <fieldset className="card p-5">
        <legend className="px-2 text-sm font-semibold uppercase tracking-wide text-brand-300">Details</legend>
        <div className="mt-3 space-y-4">
          <div>
            <label className="label" htmlFor="description">Description</label>
            <textarea id="description" name="description" rows={6} className="field" required defaultValue={listing?.description} />
            <FieldError message={err('description')} />
          </div>
          <div>
            <label className="label" htmlFor="features">Features — one per line</label>
            <textarea
              id="features" name="features" rows={5} className="field"
              defaultValue={listing?.features.join('\n')}
            />
          </div>
        </div>
      </fieldset>

      <fieldset className="card p-5">
        <legend className="px-2 text-sm font-semibold uppercase tracking-wide text-brand-300">
          Seller &amp; publishing
        </legend>
        <div className="mt-3 grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="seller_name">Seller name</label>
            <input id="seller_name" name="seller_name" className="field" required defaultValue={listing?.seller_name} />
            <FieldError message={err('seller_name')} />
          </div>
          <div>
            <label className="label" htmlFor="seller_phone">Seller phone</label>
            <input id="seller_phone" name="seller_phone" className="field" required defaultValue={listing?.seller_phone} />
            <FieldError message={err('seller_phone')} />
          </div>
        </div>

        {editing && (
          <div className="mt-4 grid gap-4 sm:grid-cols-3">
            <div>
              <label className="label" htmlFor="status">Status</label>
              <select id="status" name="status" className="field" defaultValue={listing?.status ?? 'published'}>
                <option value="published">Published</option>
                <option value="draft">Draft</option>
                <option value="archived">Archived</option>
              </select>
            </div>
            <label className="flex items-center gap-2.5 pt-6 text-sm text-slate-300">
              <input type="checkbox" name="featured" defaultChecked={listing?.featured === 1}
                     className="h-4 w-4 rounded border-ink-line bg-ink accent-brand-300" />
              Featured on homepage
            </label>
            <label className="flex items-center gap-2.5 pt-6 text-sm text-slate-300">
              <input type="checkbox" name="sold" defaultChecked={listing?.sold === 1}
                     className="h-4 w-4 rounded border-ink-line bg-ink accent-brand-300" />
              Marked as sold
            </label>
          </div>
        )}
      </fieldset>

      <div className="flex flex-wrap items-center gap-3">
        <button type="submit" className="btn-primary" disabled={pending}>
          {pending ? 'Saving…' : editing ? 'Save changes' : 'Create listing'}
        </button>
        <Link href="/admin/listings" className="btn-ghost">Back to listings</Link>
        {editing && (
          <Link href={`/listing/${listing!.slug}`} className="text-sm link-muted">
            View on site →
          </Link>
        )}
      </div>
    </form>
  );
}
